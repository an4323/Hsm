<?php
$insert = false;
if(isset($_POST['roll_number'])){
    // Set connection variables
  $server ="localhost";
  $username ="root";
  $password ="";

  // Create a database connection
  $conn = mysqli_connect($server, $username, $password, "hsm");

  // Check for connection success
  if(!$conn){
      die("connection due to this database failed due to".mysqli_connect_error());
  }
  //echo "Success connecting to the db";

  // Collect post vaiables
  $roll_number= $_POST['roll_number'];

$room_number = $_POST['room_number'];

  $sql = "UPDATE `hostel_details` SET `room_number` = '$room_number' WHERE `roll_number` = '$roll_number'";

// Execute the query
if($conn->query($sql) == true){
//  echo "Successfully inserted"; 

// Flag for successful insertion
$insert = true;

}
else{
    echo "ERROR: $sql <br> $conn->error";
}

// Close the database connection
$conn->close();

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Update</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <img class="bg" src="bg.jpg" alt="M A Hostel">
    <div class="container">
    <h1>Student Update</h3>
   
    <form action="StudentUpdate.php" method="post">
    <input type="text" name="roll_number" id="roll_number" placeholder="Enter your Roll Number"> 
    
    <input type="text" name="room_number" id="gender" placeholder="Enter your Room Number">
    
    <button class="btn">Update</button>
    
    
    </form>

</div>
    <script src="index.js"></script>
   
</body>
</html>
