 <!DOCTYPE html>
<html>
<head>
<title>Admin data</title>
<style>
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 18px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>
<th>admin_id</th>
<th>Name</th>
<th>gender</th>
<th>desgn</th>
<th>blood_group</th>
<th>phone_number</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "hsm");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT *
from admin;";
$result = $conn->query($sql);
if (!empty($result) && $result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" .$row["admin_id"]. "</td><td>" .$row["name"]. "</td><td>" . $row["gender"] . "</td><td>" . $row["desgn"]. "</td><td>" . $row["blood_group"]. "</td><td>" . $row["phone_number"]. "</td><td>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();

?>

</table>
</body>
</html>