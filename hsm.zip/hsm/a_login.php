<?php
$insert = false;
if(isset($_POST['admin_id'])){
    // Set connection variables
  $server ="localhost";
  $username ="root";
  $password ="";
  // Create a database connection
  $conn = mysqli_connect($server, $username, $password, "hsm");

  // Check for connection success
  if(!$conn){
      die("connection due to this database failed due to".mysqli_connect_error());
  }
  //echo "Success connecting to the db";

  // Collect post vaiables
  $admin_id= $_POST['admin_id'];
$password = $_POST['password'];

  $sql = "select * from admin_login where admin_id='".$_POST['admin_id']."' and password='".$_POST['password']."'";

 echo "Execute the query";
if($conn->query($sql) == true){
//echo "query inserted success";
header("Location: admin.php");
exit;
}
else{
echo "ERROR: $sql <br> $conn->error";
}

// Close the database connection
$conn->close();

}

?>






<html>
    <head>
        <title>Login Form</title>
        <link rel="stylesheet" href="login.css">
    </head>
    <body>
        <div class="sign-up-form">
            <h1> Admin Login</h1>
            <form action="a_login.php" method="post">
                <input type="text" class="input-box" name = "admin_id" placeholder="Your Admin Id">
                <input type="password" class="input-box" name = "password" placeholder="Your password">
                <button type="submit" class="signup-btn">Login in</button>
                
            </form>
        </div>
    </body>
</html>