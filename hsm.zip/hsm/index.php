<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>M A HOSTELS</title>
	<link rel="stylesheet" href="home.css">
</head>
<body>
	<div class="wrapper">
		<nav class="navbar">
			<img class="logo" src="logo.jpg">
			<ul>
				<li><a class="active" href="index.php">Home</a></li>
				<li><a href="abc.html">Facilities</a></li>
				<li><a href="gallery.html">Gallery</a></li>
				<li><a href="location.html">Location</a></li>
				<li><a href="contact.html">Contact Us</a></li>

			</ul>
</nav>
<div class="center">
	<h1>WELCOME TO M A HOSTELS</h1>
	<div class="buttons">
		<a class="btn"href="s_login.php">Student Login</a>
		<a class="btn" href="a_login.php">Admin Login</a>
		
	</div>


</div>


	</div>
</body>
</html>