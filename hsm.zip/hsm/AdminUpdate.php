<?php
$insert = false;
if(isset($_POST['admin_id'])){
    // Set connection variables
  $server ="localhost";
  $username ="root";
  $password ="";

  // Create a database connection
  $conn = mysqli_connect($server, $username, $password, "hsm");

  // Check for connection success
  if(!$conn){
      die("connection due to this database failed due to".mysqli_connect_error());
  }
  //echo "Success connecting to the db";

  // Collect post vaiables
  $admin_id= $_POST['admin_id'];

$desgn = $_POST['desgn'];

  $sql = "UPDATE `admin` SET `desgn` = '$desgn' WHERE `admin_id` = '$admin_id'";

// Execute the query
if($conn->query($sql) == true){
//  echo "Successfully inserted"; 

// Flag for successful insertion
$insert = true;

}
else{
    echo "ERROR: $sql <br> $conn->error";
}

// Close the database connection
$conn->close();

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <img class="bg" src="bg.jpg" alt="M A Hostel">
    <div class="container">
    <h1>Admin Login</h3>
   
    <form action="AdminUpdate.php" method="post">
    <input type="text" name="admin_id" id="admin_id" placeholder="Enter your admin ID"> 
    
    <input type="text" name="desgn" id="gender" placeholder="Enter your designation">
    
    <button class="btn">Submit</button>
    
    
    </form>

</div>
    <script src="index.js"></script>
   
</body>
</html>
