<?php
$insert = false;
if(isset($_POST['roll_number'])){
    // Set connection variables
  $server ="localhost";
  $username ="root";
  $password ="";
  // Create a database connection
  $conn = mysqli_connect($server, $username, $password, "hsm");

  // Check for connection success
  if(!$conn){
      die("connection due to this database failed due to".mysqli_connect_error());
  }
  //echo "Success connecting to the db";

  // Collect post vaiables
  $roll_number= $_POST['roll_number'];
$password = $_POST['password'];

  $sql = "select * from s_login where roll_number='".$_POST['roll_number']."' and password='".$_POST['password']."'";

 //echo "Execute the query";
if($conn->query($sql) == true){
echo "query inserted success";
header("Location: student.php");
exit;
}
else{
echo "ERROR: $sql <br> $conn->error";
}

// Close the database connection
$conn->close();

}

?>






<html>
    <head>
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="login.css">
    </head>
    <body>
        <div class="sign-up-form">
            <h1>Student Login</h1>
            <form action="s_login.php" method="post">
                <input type="text" class="input-box" name = "roll_number" placeholder="Your roll number">
                <input type="password" class="input-box" name = "password" placeholder="Your password">
                <button type="submit" class="signup-btn">Login in</button>
                
            </form>
        </div>
    </body>
</html>