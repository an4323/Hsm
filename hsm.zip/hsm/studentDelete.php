<html>
   
   <head>
      <title>Delete student data</title>
   </head>
   
   <body>
      <?php
         if(isset($_POST['roll_number'])) {
            $server ="localhost";
            $username ="root";
            $password ="";
           $conn = mysqli_connect($server, $username, $password, "hsm");
            
            if(! $conn ) {
               die('Could not connect: ' . mysql_error());
            }
				
            $roll_number = $_POST['roll_number'];
            
            $sql = "DELETE FROM hostel_details WHERE roll_number = '$roll_number'" ;
           if($conn->query($sql) == true){
//  echo "Successfully inserted"; 
// Flag for successful insertion
$delete = true;
}
else{
    echo "ERROR: $sql <br> $conn->error";
}
// Close the database connection
$conn->close();
}
            ?>
               <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Delete</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <img class="bg" src="bg.jpg" alt="M A Hostel">
    <div class="container">
    <h1>Student Delete</h3>
   
    <form action="studentDelete.php" method="post">
    <input type="text" name="roll_number" id="roll_number" placeholder="Enter your roll number"> 
    
    
    
    <button class="btn">Delete</button>
    
    
    </form>

</div>
    <script src="index.js"></script>
   
</body>
</html>