 <!DOCTYPE html>
<html>
<head>
<title>Students data</title>
<style>
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 18px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>
<th>roll_no</th>
<th>name</th>
<th>age</th>
<th>gender</th>
<th>birth_date</th>
<th>class</th>
<th>blood_group</th>
<th>phone_number</th>
<th>room_number</th>
<th>email</th>
<th>dt</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "hsm");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT *
from hostel_details;";
$result = $conn->query($sql);
if (!empty($result) && $result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" .$row["roll_number"]. "</td><td>" . $row["name"] . "</td><td>" . $row["age"]. "</td><td>" . $row["gender"]. "</td><td>" . $row["birth_date"]. "</td><td>" . $row["class"]. "</td><td>" . $row["blood_group"]. "</td><td>" . $row["phone_number"]. "</td><td>" . $row["room_number"]. "</td><td>" . $row["email"]. "</td><td>" . $row["dt"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();

?>

</table>
</body>
</html>