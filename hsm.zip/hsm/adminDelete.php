<html>
   
   <head>
      <title>Delete admin data</title>
   </head>
   
   <body>
      <?php
         if(isset($_POST['admin_id'])) {
            $server ="localhost";
            $username ="root";
            $password ="";
           $conn = mysqli_connect($server, $username, $password, "hsm");
            
            if(! $conn ) {
               die('Could not connect: ' . mysql_error());
            }
				
            $admin_id = $_POST['admin_id'];
            
            $sql = "DELETE FROM admin WHERE admin_id = '$admin_id'" ;
           if($conn->query($sql) == true){
//  echo "Successfully inserted"; 
// Flag for successful insertion
$delete = true;
}
else{
    echo "ERROR: $sql <br> $conn->error";
}
// Close the database connection
$conn->close();
}
            ?>
               <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Delete</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <img class="bg" src="bg.jpg" alt="M A Hostel">
    <div class="container">
    <h1>Admin Delete</h3>
   
    <form action="adminDelete.php" method="post">
    <input type="text" name="admin_id" id="admin_id" placeholder="Enter your Admin Data"> 
    
    
    
    <button class="btn">Delete</button>
    
    
    </form>

</div>
    <script src="index.js"></script>
   
</body>
</html>